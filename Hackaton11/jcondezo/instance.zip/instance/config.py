# instance/config.py

SQLALCHEMY_DATABASE_URI = 'postgresql://postgres:pacha23@localhost:5432/miniblog'