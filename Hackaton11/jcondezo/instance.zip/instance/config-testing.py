# instance/config-testing.py

SQLALCHEMY_DATABASE_URI = 'postgresql://postgres:testing@localhost:5432/modelscale_test'